Compiling the program:
	$make
Running the program:
	./containment [K-mer Size] [Number of hashes]

Both the runtime arguments are optional, when no values are passed, default values used are K-Mer Size = 20, Number of hashes = 200.

Takes 2 strings as input in the file "/input.txt". I text file should be in FASTA format.

E.g. input file:
>FASTA_123
AAAAAAAGGGGGGGCCCCCTTTTTTTTTT
>FASTA_234
AGACGACAGATTTTTTTTTTTTTTTTTTT

# GenAssembly
